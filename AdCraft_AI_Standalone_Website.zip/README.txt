ADCRAFT AI - STANDALONE WEBSITE

Files:
- index.html: complete standalone app. No framework, build step, backend or database required.

How to use:
1. Open index.html in a modern browser.
2. Enter the product details.
3. Click Build My Creative Library.
4. Search/filter the 100 creative ideas.
5. View or copy personalized prompts.
6. Product profile is stored locally in browser localStorage.

To sell:
- Upload index.html to any static hosting service.
- The app does not require a server-side database for product profile data.
- Prompts are embedded in the page.
